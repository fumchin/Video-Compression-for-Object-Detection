__version__ = "1.2.0"
git_version = "unknown"
